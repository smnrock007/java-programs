
public class ConstructOverloadingMain {

	public static void main(String[] args) {
		ConstructOverloading  defaultBox=new ConstructOverloading ();
		ConstructOverloading  squareBox=new ConstructOverloading (10);
		ConstructOverloading  userDefinedBox=new ConstructOverloading (11,12,13);
		
		System.out.println("Default box volume:"+defaultBox.volume());
		System.out.println("Square box volume:"+squareBox.volume());
		System.out.println("user Defined box volume:"+userDefinedBox.volume());

	}

}
