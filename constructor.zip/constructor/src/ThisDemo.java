
public class ThisDemo {
	int var1;
	int var2;
	public ThisDemo(int var1,int var2)
	{
		var1=var1;
		this.var2=var2;
	}
	public void display()
	{
		System.out.println("var1:"+var1);
		System.out.println("var2:"+var2);
				
	}
	public static void main(String args[])
	{
		ThisDemo obj = new ThisDemo(101,201);
		obj.display();
	}

}
