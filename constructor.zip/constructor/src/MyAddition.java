
public class MyAddition {
	public int add(int var1,int var2)
	{
		return var1+var2;
	}
	public int add(int var1,int var2,int var3)
	{
		return var1+var2+var3;
		
	}
	public int add(double var1,double var2)
	{
		return var1+var2;
	}
		public static void main(String args[])
		{
			MyAddition obj=new MyAddition();
			System.out.println("two integer parameter method:"+obj.add(100,201));
			System.out.println("two integer parameter method:"+obj.add(100,201,300));
			System.out.println("two integer parameter method:"+obj.add(100-6,201-5));
			
		}
	
}
