
public class Car {
	private String color;
	private int maxSpeed;
	
	public void carInfo()
	{
		System.out.println("car color="	+color+	" max speed=" +maxSpeed);
		
	}
	public void setcolor(String color)
	{
		this.color=color;
	}
	public void setMaxSpeed(int MaxSpeed)
	{
		this.maxSpeed=maxSpeed;
	}

}
class Maruti extends Car
{
	public void MarutiStartDemo()
	{
		Engine MarutiEngine=new Engine();
		MarutiEngine.start();
	}
}
class Engine
{
	public void start()
	{
		System.out.println("Engine started");
			
	}
	public void stop()
	{
		System.out.println("Engine stopped");
			
	}
}
class RelationDemo
{
	public static void main(String args[])
	{
		Maruti myMaruti=new Maruti();
		myMaruti.setcolor("RED");
		myMaruti.setMaxSpeed(180);
		myMaruti.carInfo();
		myMaruti.MarutiStartDemo();
		
	}
}
