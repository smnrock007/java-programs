import java.util.Scanner;
class AgeIsNegativeException extends Exception
{
	String errorMessage;
	public AgeIsNegativeException(String errorMessage)
	{
		this.errorMessage=errorMessage;
	}

	public String toString()
	{
		return errorMessage;
	}
}
class ExceptionHandling
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your age");
		int age=sc.nextInt();
		try
		{
			if(age<0)
			{
				throw new AgeIsNegativeException("Age cannot be negative");
			}
		}
		catch(AgeIsNegativeException ex)
		{
			System.out.println(ex);
		}
		
	}
}
