import java.util.Scanner;
import java.util.InputMismatchException;
class NumberForm1 {
	Scanner scan=new Scanner(System.in);
	void process() throws InputMismatchException
	{
		int a;
		System.out.println("Enter the value");
		a=scan.nextInt();
		System.out.println(a);		
		
	}
	public static void main(String args[])
	{
		NumberForm1 nu=new NumberForm1();
		nu.process();
	}

}
