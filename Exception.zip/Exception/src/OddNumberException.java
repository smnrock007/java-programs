import java.util.Scanner;
class OddNumberException extends Exception
{
	OddNumberException()
	{
		super("Odd number exception");
		
	}
	OddNumberException(String msg)
	{
		super(msg);		
	}
}
class UserDefinedExceptionDemo
{
	public static void main(String args[])
	{
		int num;
		Scanner sc=new Scanner(System.in);
		System.out.println("\n\tEnter any Number:");;
		num=Integer.parseInt(sc.nextLine());
		try
		{
			if(num%2!=0) throw (new OddNumberException());
			else
				System.out.println("\n\t"+num+"is an even number");
		}
		catch(OddNumberException Ex)
		{
			System.out.println("\n\t error:"+Ex.getMessage());
		
		}
		System.out.println("End of the program");
			
		
		
	}
}
