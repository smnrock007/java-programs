
public class NullPointerEx {
	public static void main(String args[])
	{
		try
		{
			String s =null;
			System.out.println(s.length());
			System.out.println("This statement will not be executed");
		
		}
		catch(Exception ex)
		{
			System.out.println(ex);
			ex.printStackTrace();
		}
	}

}
