 class NumberForm 
{

	public static void main(String[] args)
	{
		try
		{
			int a;
			String var=args[0];
			a=Integer.parseInt(var);
			System.out.println(a);
		}
		catch(NumberFormatException ae)
		{
			ae.printStackTrace();
		}

	}

}
