
public class StudentDetails {

	public static void main(String[] args) {
		Student s= new Student();
		s.setFirstName("Kartika");
		s.setRegNo(101);
		s.setDept("BE-CSE");
		s.setYear(4);
		s.setCgpa(8.5);
		
		
		System.out.println(s.toString());

	}

}
