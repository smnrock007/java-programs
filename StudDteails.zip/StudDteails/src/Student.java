
public class Student {
	private String firstName;	
	private int regNo;
	private String dept;
	private int year;
	private double cgpa;
	/**
	 * 
	 */
	public Student() {
		
		this.firstName = "Kartika";
		this.regNo=101;
		this.dept="BE-CSE";
		this.year=4;
		this.cgpa=8.5;
		
	
	}
	/**
	 * @param firstName
	 * @param regNo
	 * @param dept
	 * @param year
	 * @param cgpa
	 */
	public Student(String firstName, int regNo, String dept, int year, double cgpa) {
		this.firstName = firstName;
		this.regNo = regNo;
		this.dept = dept;
		this.year = year;
		this.cgpa = cgpa;
	}
	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}
	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	/**
	 * @return the regNo
	 */
	public double getRegNo() {
		return regNo;
	}
	/**
	 * @param regNo the regNo to set
	 */
	public void setRegNo(int regNo) {
		this.regNo = regNo;
	}
	/**
	 * @return the dept
	 */
	public String getDept() {
		return dept;
	}
	/**
	 * @param dept the dept to set
	 */
	public void setDept(String dept) {
		this.dept = dept;
	}
	/**
	 * @return the year
	 */
	public double getYear() {
		return year;
	}
	/**
	 * @param year the year to set
	 */
	public void setYear(int year) {
		this.year = year;
	}
	/**
	 * @return the cgpa
	 */
	public double getCgpa() {
		return cgpa;
	}
	/**
	 * @param cgpa the cgpa to set
	 */
	public void setCgpa(double cgpa) {
		this.cgpa = cgpa;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Student [firstName=" + firstName + ", regNo=" + regNo + ", dept=" + dept + ", year=" + year + ", cgpa="
				+ cgpa + "]";
	}
	
	
}
