
public class DoWhileLoop {

	public static void main(String[] args) {
		int var1=1;
		do
		{
			System.out.println(var1);
			var1++;
		}
		while(var1<=10);	

	}

}
