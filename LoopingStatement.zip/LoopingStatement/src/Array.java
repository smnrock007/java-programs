
public class Array {
	public static void main(String args[])
	{
		int i,ff[]= {1,2,3,4};
		for(i=0;i<=3;i++)
		{
			System.out.println("value:" +ff[i]);
		}
	}

}
