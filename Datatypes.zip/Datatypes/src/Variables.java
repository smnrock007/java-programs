
public class Variables {

	public static void main(String[] args) {
		
		int i=4;
		i=i+5;
		
		double a=4;
		a=a/2;
		
		int[] b=new int[5];
		b[0]=3;
		b[1]=10;
		
		String c="Hello world";
		
		boolean d=true;
		
		char e='a';
		
		System.out.println(i);
		System.out.println(a);
		System.out.println(b[0]);
		System.out.println(b[1]);
		System.out.println(c);
		System.out.println(d);
		System.out.println(e);
		
		

	}

}
