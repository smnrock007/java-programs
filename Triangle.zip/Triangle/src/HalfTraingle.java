
public class HalfTraingle {

	public static void main(String[] args) {
		

	}

}
