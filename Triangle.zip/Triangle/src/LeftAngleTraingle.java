
public class LeftAngleTraingle {
	public static void main(String[] args) 
	{
	 for(int y=1;y<=3;y++)		 
	 {
		 for(int i=3;i>y;i--)
		 {
			 System.out.print("");
		 }
		 for(int x=1;x<=y;x++ )
		 {
			 System.out.print("*");
		 }
		 System.out.println();
	 
	}
		 

	}

}
	
