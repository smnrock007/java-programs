
public class StartEx {
	static int a,b;
	static
	{
		a=10;
		b=20;
	}
	static void fun()
	{
		System.out.println("A value="+a+ "\nB value=" +b);
	}
	public static void main(String args[])
	{
		System.out.println("main_function");
		fun();
				
	}

}
