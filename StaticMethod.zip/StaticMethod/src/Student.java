
public class Student {
	
		int rollno;
		String name;
		static String collegeName;			

}
class Student_Main
{
	public static void main(String args[])
	{
		Student s=new Student();
		s.rollno=101;
		s.name="geeta";
		s.collegeName="svs";
		Student s1=new Student();
		s1.rollno=100;
		s1.name="ram";
		
		System.out.println("First Student:"+s.rollno+ " " +s.name+ " " +s.collegeName);
		System.out.println("Second Student:"+s1.rollno+ " " +s1.name+ " " +s1.collegeName);
	}
}
