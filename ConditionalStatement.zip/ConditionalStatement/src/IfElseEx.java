
import java.util.Scanner;
public class IfElseEx {
	public static void main(String args[])
	{
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a number");
		int n=input.nextInt();
		
		
		if(n==2||n==3||n==4||n==5)
		{
			System.out.println("Summer");
		}
		else if(n==6||n==7||n==8||n==9)
		{
			System.out.println("Rainy");
		}
		else if(n==10||n==11||n==12||n==1)
		{
			System.out.println("Summer");
		}
		else 
		{
			System.out.println("Please enter valid number");
		}
	}
	
	
	

}
