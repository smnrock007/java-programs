
import java.util.Scanner; 
class IfEx {
	public static void main(String args[])
	{
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a number");
		int age=input.nextInt();
		
		if(age>18)
		{
			System.out.println("Eligible for voting");
		}
		else
		{
			System.out.println("Not Eligible for voting");
		}
	}

}
